package com.shop.dao;

import com.shop.model.ProductType;

public interface ProductTypeDao extends GenericDao<ProductType> {

}
