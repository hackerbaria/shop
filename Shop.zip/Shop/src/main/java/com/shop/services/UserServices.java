package com.shop.services;

import com.shop.model.User;

public interface UserServices {
	boolean checkUser(User user);
	
	User findByUsername(String user);

}
