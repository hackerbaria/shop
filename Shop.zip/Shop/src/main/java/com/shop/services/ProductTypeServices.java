package com.shop.services;

import java.util.List;

import com.shop.model.ProductType;

public interface ProductTypeServices {
	
	List<ProductType> getAllProductTypes();

}
 